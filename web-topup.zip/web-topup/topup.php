<?php
// Konfigurasi koneksi ke database MySQL
$host = "localhost:3306";
$username = "root";
$password = "";
$database = "topup_db";

// Membuat koneksi ke database
$conn = mysqli_connect($host, $username, $password, $database);

// Memeriksa koneksi ke database
if (!$conn) {
  die("Koneksi ke database gagal: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Mengambil nilai username dan jumlah diamond dari form
  $username = $_POST["username"];
  $amount = $_POST["amount"];

  // Menjalankan query untuk menyimpan data top up diamond ke database
  $query = "INSERT INTO topup_db (username, amount) VALUES ('$username', $amount)";

  if (mysqli_query($conn, $query)) {
    $message = "Top up diamond sejumlah $amount berhasil untuk akun $username.";
  } else {
    $message = "Terjadi kesalahan: " . mysqli_error($conn);
  }
}

// Menutup koneksi ke database
mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Top Up Diamond - Hasil</title>
</head>
<body>
  <div class="container">
    <h2>Hasil Top Up Diamond</h2>
    <?php if (isset($message)): ?>
      <p><?php echo $message; ?></p>
    <?php endif; ?>
    <p><a href="topup.html">Kembali ke Form Top Up</a></p>
  </div>
</body>
</html>
